import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler,LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import accuracy_score,classification_report
from sklearn.cluster import KMeans

import plotly.express as px


#Load the data
df = pd.read_csv('hr_analytics.csv')
print(df)

#Load the data columns
df_information=df.info()
print(df_information)

#Load no. of columns and rows
df_shape=df.shape
print(df_shape)

#Finding null values
df_null_values=df.isnull().sum()
print(df_null_values)

df["YearsWithCurrManager"]=df['YearsWithCurrManager'].ffill()
df_null_values=df.isnull().sum()
print(df_null_values)

#Preprocessing
le = LabelEncoder()
for col in df.select_dtypes(include=['object']).columns:
    df[col] = le.fit_transform(df[col])
print(df)


import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

# Visualize correlations between features

plt.figure(figsize=(28, 16))
sns.heatmap(df.corr(), annot=True,cmap='coolwarm',fmt=".2f",linewidths=0.5)
plt.title('Feature Correlation Heatmap')
plt.show()


#Attition vs Age

age_att=df.groupby(['Age','Attrition']).apply(lambda x:x['DailyRate'].count()).reset_index(name='Counts')
fig=px.line(age_att,x='Age',y='Counts',color='Attrition',title='Agewise Counts of People in an Organization')
fig.show()

#Attrition vs Income

rate_att=df.groupby(['MonthlyIncome','Attrition']).apply(lambda x:x['MonthlyIncome'].count()).reset_index(name='Counts')
rate_att['MonthlyIncome']=round(rate_att['MonthlyIncome'],-3)
rate_att=rate_att.groupby(['MonthlyIncome','Attrition']).apply(lambda x:x['MonthlyIncome'].count()).reset_index(name='Counts')
fig=px.line(rate_att,x='MonthlyIncome',y='Counts',color='Attrition',title='Monthly Income basis counts of People in an Organization')
fig.show()

#Attrition vs Department
dept_att=df.groupby(['Department','Attrition']).apply(lambda x:x['DailyRate'].count()).reset_index(name='Counts')
fig=px.bar(dept_att,x='Department',y='Counts',color='Attrition',title='Department wise Counts of People in an Organization')
fig.show()

#Attrition vs Job satisfication

jsats_att=df.groupby(['JobSatisfaction','Attrition']).apply(lambda x:x['DailyRate'].count()).reset_index(name='Counts')
px.area(jsats_att,x='JobSatisfaction',y='Counts',color='Attrition',title='Job Satisfaction level Counts of People in an Organization')

#Attrition vs Work Experience

ncwrd_att=df.groupby(['NumCompaniesWorked','Attrition']).apply(lambda x:x['DailyRate'].count()).reset_index(name='Counts')
px.area(ncwrd_att,x='NumCompaniesWorked',y='Counts',color='Attrition',title='Work Experience level Counts of People in an Organization')


#Attrition vs Work duration in current role

yrscr_att=df.groupby(['YearsInCurrentRole','Attrition']).apply(lambda x:x['DailyRate'].count()).reset_index(name='Counts')
px.line(yrscr_att,x='YearsInCurrentRole',y='Counts',color='Attrition',title='Counts of People working for years in an Organization')


#Attrition vs Managers

man_att=df.groupby(['YearsWithCurrManager','Attrition']).apply(lambda x:x['DailyRate'].count()).reset_index(name='Counts')
px.line(man_att,x='YearsWithCurrManager',y='Counts',color='Attrition',title='Count of people spending years with a Manager in an Organization')

#Applying Supervised Learning Algorithm-Decision Tree Classifier
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn.model_selection import train_test_split

#splitting features and target variable for supervised learning
X = df.drop('Attrition', axis=1)
y = df['Attrition']

#Split the data for training and testing sets

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)

# Train a decision tree model
my_model = DecisionTreeClassifier(random_state=42)
my_model.fit(X_train, y_train)

# Visualize the decision tree
plt.figure(figsize=(12, 8))
tree.plot_tree(my_model, feature_names=X.columns, class_names=['Stayed', 'Attrited'], filled=True)
plt.title('Decision Tree Classifier for Attrition Prediction')
plt.show()

# Evaluate the decision tree
y_pred = my_model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))


#Normalization using MinMaxScaler
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
hr_normalized = scaler.fit_transform(df)
print(hr_normalized)

#Coverting the attrition column into numeric
df['Attrition'] = (df['Attrition'] == 'Yes').astype(int)
print(df['Attrition'])


#splitting features and target variable for supervised learning
X = df.drop('Attrition', axis=1)
y = df['Attrition']

print(X)
print(y)

#Split the data for training and testing sets

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)
print(X_train)
print(X_test)
print(y_train)
print(y_test)

# Feature scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)



"""Applying RandomForest Algorithm for better Accuracy """

from sklearn.ensemble import RandomForestClassifier

#splitting features and target variable for supervised learning
X = df.drop('Attrition', axis=1)
y = df['Attrition']

print(X)
print(y)

#Split the data for training and testing sets

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)
print(X_train)
print(X_test)
print(y_train)
print(y_test)

# Feature scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


"""Supervised Learning: Random Forest Classifier"""
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)
y_pred = rf.predict(X_test)

# Model Evaluation
print("Random Forest Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))



"""Applying Unsupervised Algorithm---K-Means clustering to show Employee Segmentation Based on Age and Monthly Income"""
from sklearn.cluster import KMeans

# Selecting features for clustering
clustering_features = df[['Age', 'YearsAtCompany', 'MonthlyIncome', 'JobSatisfaction']]

# Scale the data
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
clustering_features_scaled = scaler.fit_transform(clustering_features)

kmeans = KMeans(n_clusters=3, random_state=42)  # Assuming 3 clusters
clusters = kmeans.fit_predict(X)
df['Cluster'] = clusters

"""Visualizing Clusters"""
plt.figure(figsize=(8, 6))
sns.scatterplot(x=df['Age'], y=df['MonthlyIncome'], hue=df['Cluster'], palette='viridis')
plt.title('Employee Segmentation Based on Age and Monthly Income')
plt.xlabel('Age')
plt.ylabel('Monthly Income')
plt.show()




